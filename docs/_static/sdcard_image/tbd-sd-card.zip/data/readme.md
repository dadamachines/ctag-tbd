# Some info on the config files
- spm-config.json: Contains configuration information for the sound processor manager
    - Which plugins are available (pulled at runtime from the data/sp entries)
    - What were the last sound processors loaded for each channel
    - What patches were loaded the last time for each sound processor for each channel